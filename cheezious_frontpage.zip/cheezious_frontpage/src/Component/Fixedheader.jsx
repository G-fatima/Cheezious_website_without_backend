import { useState, useRef, useEffect } from "react";

const categories = [
  "Bhook Ka The End!",
  "Starters",
  "Somewhat Local",
  "Somewhat Sooper",
  "Cheezy Treats",
  "Pizza Deals",
  "Sandwiches & Platters",
  "Special Pizza",
  "Somewhat Amazing",
  "Pastas",
  "Burgerz",
  "Side Orders",
  "Addons",
];

const Fixedheader = ({ onCategoryChange }) => {
  const [activeCategory, setActiveCategory] = useState(0);
  const headerRef = useRef(null);

  const handleCategoryClick = (index) => {
    setActiveCategory(index);
    onCategoryChange(index);
  };

  const scrollCategories = (direction) => {
    if (headerRef.current) {
      const scrollAmount = 500;
      if (direction === "right") {
        headerRef.current.scrollLeft += scrollAmount;
      } else if (direction === "left") {
        headerRef.current.scrollLeft -= scrollAmount;
      }
    }
  };

  useEffect(() => {
    const onScroll = () => {
      const sections = document.querySelectorAll(".category-section"); 
      let currentIndex = 0;

      sections.forEach((section, index) => {
        const sectionTop = section.getBoundingClientRect().top;
        if (sectionTop >= 0 && sectionTop < window.innerHeight / 2) {
          currentIndex = index;
        }
      });

      setActiveCategory(currentIndex);
    };

    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div>
      <div className="categories-header-container">
        {/* Left Button */}
        <button className="scroll-btn left-btn" onClick={() => scrollCategories("left")}>
          &#8592;
        </button>

        <div className="categories-header" ref={headerRef}>
          {categories.map((category, index) => (
            <button
              key={index}
              className={`category-btn ${activeCategory === index ? "active" : ""}`}
              onClick={() => handleCategoryClick(index)}
              style={{ backgroundColor: activeCategory === index ? "orange" : "transparent" }}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Right Button */}
        <button className="scroll-btn right-btn" onClick={() => scrollCategories("right")}>
          &#8594;
        </button>
      </div>
    </div>
  );
};

export default Fixedheader;
