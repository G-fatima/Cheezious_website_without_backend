import "./Login.css";
import { BiSolidPhoneCall } from "react-icons/bi";
import { AiFillIdcard } from "react-icons/ai";
const Login = () => {
  return (
    <div>
       <div className="login_main">
        <div className="login_left">
          <div>
            <img src="./Images/mainLogo.webp" alt="" />
          </div>
          <div className="login_form">
            <form action="">
              <h3>Hey there,feeling hungry?</h3>
              <p>Lets enjoy your food with cheezious</p>
              <button> <BiSolidPhoneCall /> CONTINUE WITH PHONE</button>
              <button id="second_btn"> <AiFillIdcard /> COUNTINUE AS A GUEST</button>
            </form>
          </div>
        </div>
        <div className="login_pic">
          <img src="./Images/loginpicture.webp" alt="image" />
        </div>
       </div>
    </div>
  )
}


export default Login
