import PropTypes from "prop-types";
import Products from "./Products";
import "./Menucategory.css"
const Category = ({ categoryName, products }) => {
  return (
    <>
     <p id="itemsname">{categoryName}</p>
     <div className="MuiBox-root1">
     
      {products.map((product, index) => (
        <Products
          key={index}
          image={product.image}
          title={product.title}
          text={product.text}
          price={product.price} 
        />
      ))}
    </div>
    </>
   
  );
};


Category.propTypes = {
  categoryName: PropTypes.string.isRequired,
  products: PropTypes.arrayOf(
    PropTypes.shape({
      image: PropTypes.string.isRequired,
      title: PropTypes.string.isRequired,
      text: PropTypes.string.isRequired,
      price: PropTypes.number.isRequired,
    })
  ).isRequired,
};

export default Category;
