
import "./App.css";
import Carousel from "./Component/Carousel";
import Exploremenu from "./Component/Exploremenu";
import Header from "./Component/Header";
import Picturepart from "./Component/Picturepart";
import Blog from "./Component/Blog";
import Blog1 from "./Component/Blog1";
import Blog2 from "./Component/Blog2";
import Blog3 from "./Component/Blog3";
import Footer from "./Component/Footer";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Login from "./Component/Login";
import Menucategory from "./Component/Menucategory";


function App() {
  
 
  const router = createBrowserRouter([
    {
      path: "/",
      element: (
        <>
          <Header />   
          <Carousel />
          <Exploremenu />
          <Picturepart />
          <Blog />
          <Footer />
        </>
      ),
    },
    {
      path: "/login",
      element: (
        <>
          <Login />
        </>
      ),
    },
    {
    path: "/blog1",
    element: (
      <>
      <Blog1></Blog1>

      </>
    )
    },
    {
      path: "/blog2",
      element: (
        <>
        <Blog2></Blog2>
  
        </>
      )
      },
      {
        path: "/blog3",
        element: (
          <>
          <Blog3></Blog3>
    
          </>
        )
        },
        {
          path: "/menu",
          element: (
            <>
            <Menucategory />
      
            </>
          )
          },
  ]);

  return <RouterProvider router={router} />;
}

export default App;
