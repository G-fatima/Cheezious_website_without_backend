import { Link } from "react-router-dom";
import "./Blog1.css";

const Blog2 = () => {
  return (
    <div>
      <nav className="navbar bg-light">
        <div className="container-fluid">
          <div className="blog_bar">
            <div className="Container">
              <button
                className="navbar-toggler "
                type="button"
                data-bs-toggle="offcanvas"
                data-bs-target="#offcanvasNavbarLight"
                aria-controls="offcanvasNavbarLight"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>
              <div
                className="offcanvas offcanvas-start"
                id="offcanvasNavbarLight"
              >
                <div className="main">
                  <div className="offcanvas-body">
                    {/* Login Section */}
                    <div className="login">
                      <div className="rounded-circle">
                        <i
                          className="bi bi-person"
                          style={{ fontSize: "1.5rem" }}
                        ></i>
                      </div>
                      <div>
                        <p className="mb-0">Login to explore</p>
                        <p className="mb-0  fw-bold">World of flavors</p>
                      </div>
                    </div>
                    <br />
                    <button className="btn btn-outline-dark mt-2">LOGIN</button>
                    <hr />
                    {/* Menu Items */}
                    <ul className="navbar-nav mb-4">
                      <li className="nav-item">
                        <a
                          className="nav-link d-flex align-items-center fw-bold"
                          href="#"
                        >
                          <i className="bi bi-grid-fill me-2 "></i> Explore Menu
                        </a>
                      </li>
                      <li className="nav-item">
                        <a
                          className="nav-link d-flex align-items-center fw-bold"
                          href="#"
                        >
                          <i className="bi bi-shop me-2"></i> Branch Locator
                        </a>
                      </li>
                      <li className="nav-item">
                        <hr />
                      </li>
                      <li className="nav-item fw-bold">
                        <a className="nav-link" href="#">
                          Blog
                        </a>
                      </li>
                      <li className="nav-item fw-bold">
                        <a className="nav-link" href="#">
                          Privacy Policy
                        </a>
                      </li>
                    </ul>

                    {/* Footer */}
                    <div className="Footer position-absolute bottom-0 start-0 w-100  p-3 d-flex align-items-center justify-content-around">
                      <div className="d-flex align-items-center ">
                        <img
                          src="/Images/footerlogo.svg"
                          alt="Cheezious Logo"
                        />
                        <span>Cheezious Hotline</span>
                      </div>
                      <a href="#" className="Btn1  ">
                        <i className="bi bi-telephone-fill"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <img
                src="/Images/mainLogo.webp"
                alt="Logo"
                className="navbar-logo"
              />
            </div>
          </div>
          <div className="inputbox">
            <input type="text" placeholder="Find in cheezious" />
            <button type="submit">
              <p>Enter the Delivery</p>
            </button>
          </div>
          <div className="navbar-buttons">
            <div className="dropdown-container">
              <button className="dropdown-button">
                <i className="bi bi-cart-fill"></i> CART
              </button>
              <div className="dropdown-content">
                <h5>Your cart is empty</h5>
                <p>Go ahead and explore top categories</p>
              </div>
            </div>

            <Link to="/login" className="btn ">
              <i className="bi bi-person-fill"></i> LOGIN
            </Link>
          </div>
        </div>
      </nav>

      <div className="section1">
        <h1>Cheezious and Chill: The Perfect Movie Night Pairings</h1>
        <p> Syed Arslan | Published on: Oct 10, 2023 | 3 min</p>
        <img src="./Images/blog2card.webp" alt="" />
        <div id="details">
          <h3>Cheezious and Chill: The Perfect Movie Night Pairings</h3>
          <p>
            Film dekhnay ka mood hai? Lets make it a Cheezious night! Whether
            you’re in for a night of thrills, laughs, or in a deewana mood,
            weve got the perfect Cheezious combo to pair with your movie
            marathon. So grab your remote, cozy up on the sofa, and let us take
            you through a delicious tour of the best Cheezious pairings for any
            film genre.
          </p>

          <h3>Action-Packed Adventures</h3>
          <p>
            When your screen is exploding with action, you need flavors that
            pack a punch! Chicken Tandoori Pizza is your best sidekick. With its
            spicy marinated chicken and bold flavors, it’s like the hero that
            saves the day—perfect for those edge-of-your-seat moments during an
            action flick. And hey, why not add some Flaming Wings into the mix?
            Just like the best action sequences, they’re hot and unforgettable.
          </p>

          <h3>Rom-Com Evenings</h3>
          <p>
            Romantic comedies are all about sweetness and smiles, so why not
            pair them with something that matches the mood? A Cheese Lover Pizza
            from Cheezious is like a warm hug from your loved one. It’s cheezy,
            comforting, and always hits the right spot. And for those tender
            moments? A side of our Garlic Bread will make your heart melt, just
            like the film’s climax.
          </p>

          <h3>Horror Thrills</h3>
          <p>
            For those who love a good scare, a horror movie night might just be
            your thing. To keep you company through the screams, our Crunchy
            Chicken Pasta with its creamy, soothing texture will calm those
            nerves. It’s like the comforting friend you need when the suspense
            is too much. And to add a little zing to your fright night, how
            about the Spicy Ranch Pizza? Its as thrilling as the movie’s plot
            twist!
          </p>
          <h3>Animated Fun</h3>
          <p>
            Planning a family movie night with some animated classics? Let’s
            make it fun and colorful with the Chicken Fajita Pizza. Its vibrant
            toppings and mouthwatering aroma are perfect for viewers of all
            ages. And to add more joy, Cheezious Fries—because who doesn’t love
            fries during a movie? They’re the ultimate crowd-pleaser!
          </p>

          <h3>Movie Marathons</h3>
          <p>
            Got a long lineup of films? You’ll need a variety of flavors to keep
            things interesting. Start with something hearty like the Behari
            Kebab Pizza, move on to a Chicken Supreme for some sophisticated
            flair, and end with a Vegetable Pizza to keep things light and
            refreshing. Each pizza brings its own character to the table, much
            like the stars of your favorite films.
            <br />
            To order these mind-blowing flavors, just dial 111 44 66 99 or hit
            up the Cheezious app. And don’t forget, when it comes to movie
            nights, a party-size pizza is always a blockbuster idea!
            <br />
            So what are you waiting for? Pick your movie, order your favorite
            Cheezious delights, and make your movie night legendary. After all,
            every film is better with a slice (or two) of the perfect pizza.
            Cheezious ke saath, har movie night bani superhit!
          </p>
        </div>
      </div>
      <div className="Footer_main">
        <div className="footer-end">
          <div className="last">
            <div className="endpart">
              <p> Cheezious Copyright © 2024. All Rights Reserved.</p>
            </div>
            <div className="btn_foot">
              <button className="footer_button">ORDER NOW</button>
            </div>
          </div>

          <div className="endline">
            <a href="#terms">Terms & Conditions </a>
            <span>|</span>
            <a href=""> Privacy Policy</a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Blog2;
