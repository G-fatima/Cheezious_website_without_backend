import { Link } from "react-router-dom";
import "./Blog1.css";

const Blog3 = () => {
  return (
    <div>
      <nav className="navbar bg-light">
        <div className="container-fluid">
          <div className="blog_bar">
            <div className="Container">
              <button
                className="navbar-toggler "
                type="button"
                data-bs-toggle="offcanvas"
                data-bs-target="#offcanvasNavbarLight"
                aria-controls="offcanvasNavbarLight"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>
              <div
                className="offcanvas offcanvas-start"
                id="offcanvasNavbarLight"
              >
                <div className="main">
                  <div className="offcanvas-body">
                    {/* Login Section */}
                    <div className="login">
                      <div className="rounded-circle">
                        <i
                          className="bi bi-person"
                          style={{ fontSize: "1.5rem" }}
                        ></i>
                      </div>
                      <div>
                        <p className="mb-0">Login to explore</p>
                        <p className="mb-0  fw-bold">World of flavors</p>
                      </div>
                    </div>
                    <br />
                    <button className="btn btn-outline-dark mt-2">LOGIN</button>
                    <hr />
                    {/* Menu Items */}
                    <ul className="navbar-nav mb-4">
                      <li className="nav-item">
                        <a
                          className="nav-link d-flex align-items-center fw-bold"
                          href="#"
                        >
                          <i className="bi bi-grid-fill me-2 "></i> Explore Menu
                        </a>
                      </li>
                      <li className="nav-item">
                        <a
                          className="nav-link d-flex align-items-center fw-bold"
                          href="#"
                        >
                          <i className="bi bi-shop me-2"></i> Branch Locator
                        </a>
                      </li>
                      <li className="nav-item">
                        <hr />
                      </li>
                      <li className="nav-item fw-bold">
                        <a className="nav-link" href="#">
                          Blog
                        </a>
                      </li>
                      <li className="nav-item fw-bold">
                        <a className="nav-link" href="#">
                          Privacy Policy
                        </a>
                      </li>
                    </ul>

                    {/* Footer */}
                    <div className="Footer position-absolute bottom-0 start-0 w-100  p-3 d-flex align-items-center justify-content-around">
                      <div className="d-flex align-items-center ">
                        <img
                          src="/Images/footerlogo.svg"
                          alt="Cheezious Logo"
                        />
                        <span>Cheezious Hotline</span>
                      </div>
                      <a href="#" className="Btn1  ">
                        <i className="bi bi-telephone-fill"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <img
                src="/Images/mainLogo.webp"
                alt="Logo"
                className="navbar-logo"
              />
            </div>
          </div>
          <div className="inputbox">
            <input type="text" placeholder="Find in cheezious" />
            <button type="submit">
              <p>Enter the Delivery</p>
            </button>
          </div>
          <div className="navbar-buttons">
            <div className="dropdown-container">
              <button className="dropdown-button">
                <i className="bi bi-cart-fill"></i> CART
              </button>
              <div className="dropdown-content">
                <h5>Your cart is empty</h5>
                <p>Go ahead and explore top categories</p>
              </div>
            </div>

            <Link to="/login" className="btn ">
              <i className="bi bi-person-fill"></i> LOGIN
            </Link>
          </div>
        </div>
      </nav>

      <div className="section1">
        <h1>How to Host the Ultimate Pizza Party with Cheezious</h1>
        <p> Syed Arslan | Published on: Oct 11, 2023 | 3 min</p>
        <img src="./Images/blog3card.webp" alt="" />
        <div id="details">
          <h3>How to Host the Ultimate Pizza Party with Cheezious</h3>
          <p>
            
          When hosting the ultimate pizza party, Cheezious is your secret weapon! With its range of flavors that cater perfectly to the Pakistani palate, youre just a call or click away from turning your gathering into a full on cheezy khushiyon bhari party. Heres your guide to throwing a pizza party that’s fun and flavorful
          </p>

          <h3>1. Choosing the Right Flavors:</h3>
          <p>
          Kick things off with a variety of pizzas to make sure theres something for everyone. Mix classics like our signature Crown Crust with local favorites such as the fiery Chicken Tikka and the rich and beefy Stuff Crust. And yes, make sure to order the party size to keep the fun going without running out!
          </p>

          <h3>Rom-Com Evenings</h3>
          <p>
            Romantic comedies are all about sweetness and smiles, so why not
            pair them with something that matches the mood? A Cheese Lover Pizza
            from Cheezious is like a warm hug from your loved one. It’s cheezy,
            comforting, and always hits the right spot. And for those tender
            moments? A side of our Garlic Bread will make your heart melt, just
            like the film’s climax.
          </p>

          <h3>2. Add Desi Twists: </h3>
          <p>
          Spice up your menu with some desi sides. Offer options like Flaming chicken wigns, cheese sticks, and fries for a full-on feast. As for drinks, Have lots of chilled soft drinks with lots of ice to quench the thirst because it’s not a summer party without the ice.
          </p>
          <h3>3. Setting the Mood: </h3>
          <p>
          Decorate with vibrant, fun elements that reflect a hearty, desi vibe—think bright tablecloths and fun Pakistani music in the background to keep the energy up.
          </p>

          <h3>4. Games and Entertainment: </h3>
          <p>
          How about a game of musical chairs, or antaakshari? Its a surefire fun way to engage everyone and spice up the party.
            </p>
            <h3>5. Capture the Fun: </h3>
            <p>It goes without saying, make sure to take lots and lots of pictures to keep the memories of the even alive!</p>
            <h3>6. Ordering Made Easy: </h3>
            <p>Call 111 44 66 99 or order through the Cheezious app to get everything delivered hot and fresh to your doorstep. Efficient, convenient, and forever delicious!
<br />
Hosting a pizza party with Cheezious is more than about enjoying great food; its about creating joyful memories with your friends and loved ones. So, dial up the desi, bring out the pizzas, and let the good times roll! Coz abhi tou party shuru hui hai!</p>
            
        </div>
      </div>
      <div className="Footer_main">
        <div className="footer-end">
          <div className="last">
            <div className="endpart">
              <p> Cheezious Copyright © 2024. All Rights Reserved.</p>
            </div>
            <div className="btn_foot">
              <button className="footer_button">ORDER NOW</button>
            </div>
          </div>

          <div className="endline">
            <a href="#terms">Terms & Conditions </a>
            <span>|</span>
            <a href=""> Privacy Policy</a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Blog3;
