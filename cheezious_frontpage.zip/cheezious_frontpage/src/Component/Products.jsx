import { useState } from "react";
import PropTypes from "prop-types";
import "./Menucategory.css";
import SigninModel from "./SigninModel";
const products = ({ image, title, text, price }) => {
  const [isModalOpen, setModalOpen] = useState(false);

  const handleAddToCart = () => {
    setModalOpen(true);
  };

  const handleCloseModal = () => {
    setModalOpen(false);
  };

  const handleSendOtp = () => {
    console.log("OTP sent!");
  };
  return (
    <div className="card">
      <img src={image} className="card-img-top" alt={title} />
      <div className="card-body">
        <h5 className="card-title">{title}</h5>
        <p className="card-text">{text}</p>
        <p className="card-price">
          <strong>Price: </strong>{price}
        </p>
        <button className="btnitems"  onClick={handleAddToCart} >
          Add to Cart
        </button>
      <SigninModel isOpen={isModalOpen} onClose={handleCloseModal} onSendOtp={handleSendOtp} />
      </div>
    </div>
  );
};

products.propTypes = {
  image: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  text: PropTypes.string.isRequired,
  price: PropTypes.number.isRequired,
};

export default products;
