import "./Offcanvas.css";
const Offcanvas = () => {
  return (
    <div>

<div className="container">
          <button
            className="navbar-toggler "
            type="button"
            data-bs-toggle="offcanvas"
            data-bs-target="#offcanvasNavbarLight"
            aria-controls="offcanvasNavbarLight"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="offcanvas offcanvas-start" id="offcanvasNavbarLight">
           <div className="main">
           <div className="offcanvas-body">
              {/* Login Section */}
              <div className="login">       
                  <div className="rounded-circle">
                    <i
                      className="bi bi-person"
                      style={{ fontSize: "1.5rem" }}
                    ></i>
                  </div>
                <div>
                <p className="mb-0">Login to explore</p>
                <p className="mb-0  fw-bold">World of flavors</p>
                </div>
              </div>
              <br />
              <button className="btn btn-outline-dark mt-2">LOGIN</button>
  <hr />
              {/* Menu Items */}
              <ul className="navbar-nav mb-4">
                <li className="nav-item">
                  <a className="nav-link d-flex align-items-center fw-bold" href="#">
                    <i className="bi bi-grid-fill me-2 " ></i> Explore Menu
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link d-flex align-items-center fw-bold" href="#">
                    <i className="bi bi-shop me-2"></i> Branch Locator
                  </a>
                </li>
                <li className="nav-item">
                  <hr />
                </li>
                <li className="nav-item fw-bold">
                  <a className="nav-link" href="#">
                    Blog
                  </a>
                </li>
                <li className="nav-item fw-bold">
                  <a className="nav-link" href="#">
                    Privacy Policy
                  </a>
                </li>
              </ul>

              {/* Footer */}
              <div className="Footer position-absolute bottom-0 start-0 w-100  p-3 d-flex align-items-center justify-content-around" >
                <div className="d-flex align-items-center ">
                  <img
                    src="/Images/footerlogo.svg"
                    alt="Cheezious Logo" 
                  />
                  <span >Cheezious Hotline</span>
                </div>
                <a href="#" className="Btn1  ">
                  <i className="bi bi-telephone-fill"></i>
                </a>
              </div>
            </div>
           </div>
          </div>
        </div>
      
    </div>
  );
};

export default Offcanvas;
