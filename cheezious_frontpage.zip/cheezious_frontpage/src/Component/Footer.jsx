import "./Footer.css"
const Footer = () => {
  return (
    <div className="footer_main">
      <div className="footer">
        <div className="footer-form ">
        <form action="" id="form">
            <h1>Special Offers & News</h1>
            <p>Subscribe now for news, promotions and more delivered right to your inbox</p>
            <input type="text" placeholder="Enter Email Address" id="input"/>
            <button type="submit" id="btn">SUBSCRIBE</button>
        </form>
        </div>
       
      </div>
      <div className="footer-end">
        <div className="last">
        <div className="endpart">
          <p> Cheezious Copyright © 2024. All Rights Reserved.</p>
          </div>
          <div className="btn_foot">
          <button className="footer_button">ORDER NOW</button>
          </div>
        </div>
         
          <div className="endline">
       <a href="#terms">Terms & Conditions  </a>
        <span>|</span>
        <a href="">  Privacy Policy</a>
       </div> 
           
        </div>
      
    </div>
  )
}

export default Footer
