import { Link } from "react-router-dom";
import "./Blog1.css";
const Blog1 = () => {
  return (
    <div>
        <nav className="navbar bg-light">
        <div className="container-fluid">
          <div className="blog_bar">
<div className="Container">
          <button
            className="navbar-toggler "
            type="button"
            data-bs-toggle="offcanvas"
            data-bs-target="#offcanvasNavbarLight"
            aria-controls="offcanvasNavbarLight"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="offcanvas offcanvas-start" id="offcanvasNavbarLight">
           <div className="main">
           <div className="offcanvas-body">
              {/* Login Section */}
              <div className="login">       
                  <div className="rounded-circle">
                    <i
                      className="bi bi-person"
                      style={{ fontSize: "1.5rem" }}
                    ></i>
                  </div>
                <div>
                <p className="mb-0">Login to explore</p>
                <p className="mb-0  fw-bold">World of flavors</p>
                </div>
              </div>
              <br />
              <button className="btn btn-outline-dark mt-2">LOGIN</button>
  <hr />
              {/* Menu Items */}
              <ul className="navbar-nav mb-4">
                <li className="nav-item">
                  <a className="nav-link d-flex align-items-center fw-bold" href="#">
                    <i className="bi bi-grid-fill me-2 " ></i> Explore Menu
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link d-flex align-items-center fw-bold" href="#">
                    <i className="bi bi-shop me-2"></i> Branch Locator
                  </a>
                </li>
                <li className="nav-item">
                  <hr />
                </li>
                <li className="nav-item fw-bold">
                  <a className="nav-link" href="#">
                    Blog
                  </a>
                </li>
                <li className="nav-item fw-bold">
                  <a className="nav-link" href="#">
                    Privacy Policy
                  </a>
                </li>
              </ul>

              {/* Footer */}
              <div className="Footer position-absolute bottom-0 start-0 w-100  p-3 d-flex align-items-center justify-content-around" >
                <div className="d-flex align-items-center ">
                  <img
                    src="/Images/footerlogo.svg"
                    alt="Cheezious Logo" 
                  />
                  <span >Cheezious Hotline</span>
                </div>
                <a href="#" className="Btn1  ">
                  <i className="bi bi-telephone-fill"></i>
                </a>
              </div>
            </div>
           </div>
          </div>
          
        </div>
        <div>
   <img src="/Images/mainLogo.webp" alt="Logo" className="navbar-logo" />
   </div>
          </div>
         <div className="inputbox">
            <input type="text" placeholder="Find in cheezious" />
            <button type="submit">
             <p>Enter the Delivery</p>
            </button>
 
         </div>
          <div className="navbar-buttons">
    <div className="dropdown-container">
      <button className="dropdown-button"><i className="bi bi-cart-fill"></i> CART</button>
      <div className="dropdown-content">
       <h5>Your cart is empty</h5>
       <p>Go ahead and explore top categories</p>
      </div>
    </div>


            <Link to="/login" className="btn ">
              <i className="bi bi-person-fill"></i> LOGIN
            </Link>
          </div>
        </div>
      </nav>

    <div className="section1">
        <h1>Cheezious: The Awami Brand Thats All About Local Love</h1>
        <p> Syed Arslan | Published on: Oct 11, 2023 | 2 min</p>
        <img src="./Images/blog1card.webp" alt="" />
        <div id="details">
          <h3>Cheezious: The Awami Brand Thats All About Local Love</h3>
            <p>At Cheezious, we do more than serve food; we craft a community experience,
               with a pinch of desi tadka and a whole lot of Pakistani pride. We believe in food as
                something that binds us to our heritage, celebrates our roots and showcases what makes Pakistan truly special. So, lets dive into how Cheezious is not just a food chain but a flag bearer of all-things local and especially a Proud Pakistani Brand!</p>
                <h3>Locally Sourced, Ghar ka Taste:</h3>
                <p>If you have you ever wondered why every bite of your favorite Cheezious dish has a local touch? Thats because it does! From the tangy tomatoes in your sauce to the crunchy onions topping your pizza, most of what we use comes from our own backyard—Pakistan. By sourcing our ingredients locally, we not only bring you the freshest flavors but also support our local farmers. This is our way of keeping the community close and the quality even closer</p>
                <h3>
                Desi Delights on a Dough Base:</h3>
                <p>We’re all about mirroring the vibrant culture of our streets in the menu. Every item tells a story, whether it’s the spicy Hot N Spicy Pizza or the tangy Oven Baked Wings. The story of local taste meeting world-class culinary standards. It’s like bringing a piece of Pakistan to your plate, seasoned with love and a dash of cheezy peezy innovation.</p>
                <h3>Mission: Awami Happiness:</h3>
                <p>Cheezious i on a mission—a mission to be the Awami (people’s) brand. What does that mean? It means making sure that whether you’re a student in Islamabad needing a quick bite between classes, a family in Karachi hosting a birthday bash, or a couple in Lahore looking for a comfort food night, Cheezious is your go-to spot. Affordable, accessible, and absolutely lip-smacking!</p>
                <h3>Sustainability and Social Responsibility:</h3>
                <p>But hey, its not just about what goes on your plate. Were also keen on how we impact the world around us. Our focus on local sourcing is just part of our broader commitment to sustainability. By reducing long transport routes, we not only cut down on our carbon footprint but also ensure that everything you eat is planet-friendly.</p>
                <h3>
                Kyun ke Local Hai Lajawab:</h3>
                <p>In the end, it all boils down to one simple truth: local hai lajawab. By sticking close to our roots and embracing the rich flavors of Pakistan, Cheezious is more than just a food brand; it’s a celebration of Pakistani culture. Every food parcel we deliver carries this message home, and you are reminded of it in every bite.
                  <br />
                  So next time you bite into your favorite Cheezious food, remember, you’re biting a piece of Pakistan, served fresh and hot, just for you!
                  <br />
                  Explore more and join us on this flavorful journey at Cheezious.com. Let’s make every meal a celebration of our local heritage!
                </p>
        </div>
    </div>
    <div className="Footer_main">
    
      <div className="footer-end">
        <div className="last">
        <div className="endpart">
          <p> Cheezious Copyright © 2024. All Rights Reserved.</p>
          </div>
          <div className="btn_foot">
          <button className="footer_button">ORDER NOW</button>
          </div>
        </div>
         
          <div className="endline">
       <a href="#terms">Terms & Conditions  </a>
        <span>|</span>
        <a href="">  Privacy Policy</a>
       </div> 
           
        </div>
      
    </div>
    </div>
  )
}

export default Blog1
