import "./Exploremenu.css";
import { useState } from "react";
import { Link } from "react-router-dom"; 

const menuItems = [
  { id: 1, title: "BHOOK KA THE END!", img: "./Images/card1.webp", link: "/menu" },
  { id: 2, title: "STARTERS", img: "./Images/card2.webp", link: "/menu" },
  { id: 3, title: "SOMEWHAT LOCAL", img: "./Images/card3.webp", link: "/menu" },
  { id: 4, title: "SOMEWHAT SOOPER", img: "./Images/card4.webp", link: "/menu" },
  { id: 5, title: "VEGGIE PIZZA", img: "./Images/card5.webp", link: "/menu" },
  { id: 6, title: "MEAT FEAST", img: "./Images/card6.webp", link: "/menu" },
  { id: 7, title: "CHEEZY TREATS", img: "./Images/card7.webp", link: "/menu" },
  { id: 8, title: "PIZZA DEALS", img: "./Images/card8.webp", link: "/menu" },
  { id: 9, title: "SANDWICHES & PLATTERS", img: "./Images/card9.webp", link: "/menu" },
  { id: 10, title: "SPECIAL PIZZA", img: "./Images/card10.webp", link: "/menu" },
  { id: 11, title: "SOMEWHAT AMAZING", img: "./Images/card11.webp", link: "/menu" },
  { id: 12, title: "SIDE ORDERS", img: "./Images/card12.webp", link: "/menu" },
];

const Exploremenu = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const itemsPerPage = 4;

  const handleNext = () => {
    if (currentIndex + itemsPerPage < menuItems.length) {
      setCurrentIndex(currentIndex + itemsPerPage);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - itemsPerPage);
    }
  };

  const displayedItems = menuItems.slice(
    currentIndex,
    currentIndex + itemsPerPage
  );

  return (
    <div id="top">
      <div className="main">
        <div className="menu_header">
          <h2>Explore Menu</h2>
          <a href="#" className="view-all">VIEW ALL</a>
        </div>
        <div className="menu_items">
          <div className="Carousel-Container">
            <button
              onClick={handlePrev}
              className="Carousel-button Carousel-button-left"
            >
              &lt;
            </button>
            <div className="Carousel-items">
              {displayedItems.map((item) => (
                <div key={item.id} className="Carousel-item">
                  <Link to={item.link}> 
                    <img src={item.img} alt={item.title} />
                    <p>{item.title}</p>
                  </Link>
                </div>
              ))}
            </div>
            <button
              onClick={handleNext}
              className="Carousel-button Carousel-button-right"
            >
              &gt;
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Exploremenu;
