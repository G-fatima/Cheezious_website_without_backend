import { Link } from "react-router-dom";
import "./Menucategory.css";
import Fixedheader from "./Fixedheader";
import Category from "./Category";


const Menucategory = () => {
  const handleCategoryChange = (index) => {
    const section = document.querySelector(`#category-${index}`);
    if (section) {
      section.scrollIntoView({ behavior: "smooth" });
    }
  };
  const categories = [
    {
      categoryName: "Bhook ka the end",
      products: [
        {
          image: "./Images/card1.webp",
          title: "Bazooka",
          text: "Delicious meal to satisfy your hunger.",
          link: "#",
          price: 10.99,
        },
      ],
    },
    {
      categoryName: "Starters",
      products: [
        {
          image: "./Images/menu2.webp",
          title: "Cheezy Sticks",
          text: "A great way to start your meal.",
          price: "Rs. 630",
        },
        {
          image: "./Images/menu3.webp",
          title: "Oven Bked Wings",
          text: "A savory starter for your dinner.",
          price: "Rs.600",
        },
        {
          image: "./Images/menu4.webp",
          title: "Flaming Wings",
          text: "Crispy and fresh appetizer.",
          price: "Rs.650",
        },
        {
          image: "./Images/menu5.webp",
          title: "Calzone Chunks",
          text: "A delightful snack to begin with.",
          price: "Rs.1,150",
        },
        {
          image: "./Images/menu6.webp",
          title: "Arabic Rolls",
          text: "Perfectly spiced starter for everyone.",
          price: "Rs.690",
        },
        {
          image: "./Images/menu7.webp",
          title: "Behari Roll",
          text: "Perfectly spiced starter for everyone.",
          price: "Rs.650",
        },
      ],
    },
    {
      categoryName: "Somewhat local",
      products: [
        {
          image: "./Images/menu8.webp",
          title: "Chicken Tikka ",
          text: "A great way to start your meal.",
          price: "Rs.690",
        },
        {
          image: "./Images/menu9.webp",
          title: "Chicken Fajita",
          text: "A savory starter for your dinner.",
          price: "Rs.690",
        },
        {
          image: "./Images/menu10.webp",
          title: "Chicken Lover",
          text: "Crispy and fresh appetizer.",
          price: "Rs.725",
        },
        {
          image: "./Images/menu11.webp",
          title: "Chicken Tandoori",
          text: "A delightful snack to begin with.",
          price: "Rs.690",
        },
        {
          image: "./Images/menu12.webp",
          title: "Hot n Spicy",
          text: "Perfectly spiced starter for everyone.",
          price: "Rs.690",
        },
        {
          image: "./Images/menu13.webp",
          title: "Vegetable pizza",
          text: "Perfectly spiced starter for everyone.",
          price: "Rs.690",
        },
      ],
    },
    {
      categoryName: "Somewhat Sooper",
      products: [
        {
          image: "./Images/menu14.webp",
          title: "Euro",
          text: "A great way to start your meal.",
          price: "Rs.990",
        },
        {
          image: "./Images/menu15.webp",
          title: "Chiken Supreme",
          text: "A savory starter for your dinner.",
          price: "Rs.649",
        },
        {
          image: "./Images/menu16.webp",
          title: "Chicken Mushroom",
          text: "Crispy and fresh appetizer.",
          price: "Rs.725",
        },
        {
          image: "./Images/menu17.webp",
          title: "Sausage Pizza",
          text: "A delightful snack to begin with.",
          price: "Rs.650",
        },
        {
          image: "./Images/menu18.webp",
          title: "Cheese lover Pizza",
          text: "Perfectly spiced starter for everyone.",
          price: "Rs.699",
        },
        {
          image: "./Images/menu19.webp",
          title: "Chicken Pepperonic",
          text: "Perfectly spiced starter for everyone.",
          price: "Rs.699",
        },
      ],
    },
    {
      categoryName: "Cheezy Treats",
      products: [
        {
          image: "./Images/menu14.webp",
          title: "Cheezious Special",
          text: "A great way to start your meal.",
          price: "Rs.1,500",
        },
        {
          image: "./Images/menu15.webp",
          title: "Behari Kebab",
          text: "A savory starter for your dinner.",
          price: "Rs.1,550",
        },
        {
          image: "./Images/menu16.webp",
          title: "Chiken Extreme",
          text: "Crispy and fresh appetizer.",
          price: "Rs.1,550",
        },
      ],
    },
    {
      categoryName: "Pizza Deals",
      products: [
        {
          image: "./Images/menu14.webp",
          title: "Small pizza Deal",
          text: "A great way to start your meal.",
          price: "Rs.750",
        },
        {
          image: "./Images/menu15.webp",
          title: "Regular Pizza Deal",
          text: "A savory starter for your dinner.",
          price: "Rs.1,450",
        },
        {
          image: "./Images/menu16.webp",
          title: "Large pizza deal",
          text: "Crispy and fresh appetizer.",
          price: "Rs.1,990",
        },
      ],
    },
    {
      categoryName: "Sandwiches & Platters",
      products: [
        {
          image: "./Images/menu14.webp",
          title: "Special Roasted",
          text: "A great way to start your meal.",
          price: "Rs.1,200",
        },
        {
          image: "./Images/menu15.webp",
          title: "Starter 2",
          text: "A savory starter for your dinner.",
          price: "Rs.920",
        },
        {
          image: "./Images/menu16.webp",
          title: "Pizza Stacker",
          text: "Crispy and fresh appetizer.",
          price: "Rs.920",
        },
        {
          image: "./Images/menu14.webp",
          title: "Euro Sandwich",
          text: "A great way to start your meal.",
          price: "Rs.920",
        },
        {
          image: "./Images/menu14.webp",
          title: "Classic Roll Plate",
          text: "A great way to start your meal.",
          price: "Rs.1200",
        },
      ],
    },
    {
      categoryName: "Special Pizza",
      products: [
        {
          image: "./Images/menu14.webp",
          title: "Crown Crust",
          text: "A great way to start your meal.",
          price: "Rs.1,550",
        },
        {
          image: "./Images/menu15.webp",
          title: "Stuff Crust pizza",
          text: "A savory starter for your dinner.",
          price: "Rs.1,600",
        },
       
       
      ],
    },
    {
      categoryName: "Somewhat Amazing",
      products: [
        {
          image: "./Images/menu14.webp",
          title: "Somewhat Amazing",
          text: "A great way to start your meal.",
          price: "Rs. 1,250",
        },
        {
          image: "./Images/menu15.webp",
          title: "Somewhat amazing",
          text: "A savory starter for your dinner.",
          price: "Rs. 1,750",
        },
        {
          image: "./Images/menu16.webp",
          title: "Somewahat Amazing",
          text: "3Bazinga Burger,Large Fries,1 liter Drink",
          price: "Rs.1,890",
        },
        {
          image: "./Images/menu14.webp",
          title: "Somewhat amazing",
          text: "A great way to start your meal.",
          price: "Rs. 2,150",
        },
    
      ],
    },
    {
      categoryName: "Pastas",
      products: [
        {
          image: "./Images/menu14.webp",
          title: "Fettuccine Alfredo",
          text: "A great way to start your meal.",
          price: "Rs. 1,050",
        },
        {
          image: "./Images/menu15.webp",
          title: "Crunchy Chicken",
          text: "A savory starter for your dinner.",
          price: "Rs.950",
        },
      
       
      ],
    },
    {
      categoryName: "Burgerz",
      products: [
        {
          image: "./Images/menu14.webp",
          title: "Reggy Burger",
          text: "Perfectly fried chicken patty with fresh lettuce and sauce in a sesame seed bun....",
          price: "Rs.390",
        },
        {
          image: "./Images/menu15.webp",
          title: "Bazinga Burger",
          text: "A savory starter for your dinner.",
          price: "Rs.560",
        },
        {
          image: "./Images/menu16.webp",
          title: "Bazooka ",
          text: "Crispy and fresh appetizer.",
          price: "Rs.630",
        },
       
      ],
    },
    {
      categoryName: "Side Orders",
      products: [
        {
          image: "./Images/menu14.webp",
          title: "Fries",
          price: "Rs.220",
        },
        {
          image: "./Images/menu15.webp",
          title: "Starter 2",
          text: "A savory starter for your dinner.",
          price: "Rs.450",
        },
        {
          image: "./Images/menu16.webp",
          title: "Chicken Piece",
          price: "Rs.300",
        },
        
      ],
    },
    {
      categoryName: "Addons",
      products: [
        {
          image: "./Images/menu14.webp",
          title: "Juice",
          price: "Rs.60",
        },
        {
          image: "./Images/menu15.webp",
          title: "Mayo Dip",
          price: "Rs.80",
        },
        {
          image: "./Images/menu16.webp",
          title: "Water small",
          price: "Rs.60",
        },
        {
          image: "./Images/menu14.webp",
          title: "Soft Drink",
          price: "Rs.100",
        },
      
      ],
    },
  ];

  return (
    <div>
      <nav className="navbar bg-light">
        <div className="container-fluid">
          <div className="blog_bar">
            <div className="Container">
              <button
                className="navbar-toggler"
                type="button"
                data-bs-toggle="offcanvas"
                data-bs-target="#offcanvasNavbarLight"
                aria-controls="offcanvasNavbarLight"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>
              <div className="offcanvas offcanvas-start" id="offcanvasNavbarLight">
                <div className="main">
                  <div className="offcanvas-body">
                    {/* Login Section */}
                    <div className="login">
                      <div className="rounded-circle">
                        <i className="bi bi-person" style={{ fontSize: "1.5rem" }}></i>
                      </div>
                      <div>
                        <p className="mb-0">Login to explore</p>
                        <p className="mb-0 fw-bold">World of flavors</p>
                      </div>
                    </div>
                    <br />
                    <button className="btn btn-outline-dark mt-2">LOGIN</button>
                    <hr />
                    {/* Menu Items */}
                    <ul className="navbar-nav mb-4">
                      <li className="nav-item">
                        <a className="nav-link d-flex align-items-center fw-bold" href="#">
                          <i className="bi bi-grid-fill me-2"></i> Explore Menu
                        </a>
                      </li>
                      <li className="nav-item">
                        <a className="nav-link d-flex align-items-center fw-bold" href="#">
                          <i className="bi bi-shop me-2"></i> Branch Locator
                        </a>
                      </li>
                      <li className="nav-item">
                        <hr />
                      </li>
                      <li className="nav-item fw-bold">
                        <a className="nav-link" href="#">
                          Blog
                        </a>
                      </li>
                      <li className="nav-item fw-bold">
                        <a className="nav-link" href="#">
                          Privacy Policy
                        </a>
                      </li>
                    </ul>

                    {/* Footer */}
                    <div className="Footer position-absolute bottom-0 start-0 w-100 p-3 d-flex align-items-center justify-content-around">
                      <div className="d-flex align-items-center">
                        <img src="/Images/footerlogo.svg" alt="Cheezious Logo" />
                        <span>Cheezious Hotline</span>
                      </div>
                      <a href="#" className="Btn1">
                        <i className="bi bi-telephone-fill"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <img src="/Images/mainLogo.webp" alt="Logo" className="navbar-logo" />
            </div>
          </div>
          <div className="inputbox">
            <input type="text" placeholder="Find in cheezious" />
            <button type="submit">
              <p>Enter the Delivery</p>
            </button>
          </div>
          <div className="navbar-buttons">
            <div className="dropdown-container">
              <button className="dropdown-button">
                <i className="bi bi-cart-fill"></i> CART
              </button>
              <div className="dropdown-content">
                <h5>Your cart is empty</h5>
                <p>Go ahead and explore top categories</p>
              </div>
            </div>

            <Link to="/login" className="btn">
              <i className="bi bi-person-fill"></i> LOGIN
            </Link>
          </div>
        </div>
      </nav>
      
        {/* Header Menu */}
      <Fixedheader onCategoryChange={handleCategoryChange}  />
      {/* card */}
      <div className="menuheader">
      <div className="menucontent">
        {categories.map((category, index) => (
            <div key={index} className="category-section" id={`category-${index}`}>
          <Category
            key={index}
            categoryName={category.categoryName}
            products={category.products}
          />
          </div>
        ))}
      </div>
      <div className="cart-summary">
        <h5>YOUR CART IS EMPTY</h5>
        <p>Go ahead and explore top categories.</p>
      </div>
    </div>
    </div>
  );
};

export default Menucategory;








