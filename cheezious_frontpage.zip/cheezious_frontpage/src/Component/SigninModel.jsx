import "./SigninModel.css"
const SigninModel = ({ isOpen, onClose, onSendOtp }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-box">
        <div className="modal-header">
          <h2>Cheezious</h2>
          <button onClick={onClose} className="close-btn">X</button>
        </div>
        <div className="modal-body">
          <p>Please Sign-In to Place an Order</p>
          <input
            type="tel"
            placeholder="301xxxxxxx"
            className="phone-input"
            maxLength="10"
          />
          <button onClick={onSendOtp} className="send-otp-btn">Send OTP</button>
        </div>
      </div>
    </div>
  );
};

export default SigninModel;
