import "./Picturepart.css";
const Picturepart = () => {
  return (
    <div>
    <div className="container">
    <div className="card" >
  <img src="/Images/pic1.webp" className="card-img-top" alt="..." />
  <div className="card-body">
    <p className="card-text">Delivering cheezy   Khushiyan</p>
  </div>
</div>

<div className="card" >
  <img src="/Images/pic2.webp" className="card-img-top" alt="..." />
  <div className="card-body">
    <p className="card-text">Fastest Growing Brand of the Year</p>
  </div>
</div>

<div className="card" >
  <img src="/Images/pic3.webp" className="card-img-top" alt="..." />
  <div className="card-body">
    <p className="card-text">Made with fresh, local ingredients and love</p>
  </div>
</div>
    </div>
   
   
    </div>
  )
}

export default Picturepart
