import "./Blog.css";
import { Link } from "react-router-dom";

const Blog = () => {
  return (
    <div id="top">
        <div className="container1">
        <div className="menu-header">
      <h2>Blogs</h2>
      <a href="#" className="view-all">VIEW ALL</a>
    </div>

    <div className="blog-posts">
  
    <Link to="/blog1" className="card-link">
      <div className="card">
        <img src="./Images/blog1.webp" className="cardimg" alt="..." />
        <div className="card-img-overlay">
          <p className="cardtext text-bg-dark">
            Cheezious: The Awami Brand That All About Local Love
            <br />
            <small>Learn more</small>
          </p>
        </div>
      </div>
    </Link>

    <div className="card">
  <Link to="/blog2" className="card-link">
    <img src="./Images/blog2.webp" className="cardimg" alt="..." />
    <div className="card-img-overlay">
      <p className="cardtext text-bg-dark">
        Cheezious and Chill: The Perfect Movie Night Pairings
        <br />
        <small>Learn more</small>
      </p>
    </div>
  </Link>
</div>

<Link to="/blog3" className="card-link">
  <div className="card">
    <img src="./Images/blog3.webp" className="cardimg" alt="..." />
    <div className="card-img-overlay">
      <p className="cardtext text-bg-dark ">
        How to Host the Ultimate Pizza Party with Cheezious
        <br />
        <small>Learn more</small>
      </p>
    </div>
  </div>
</Link>
        </div>
        </div>        
    </div>
  )
}

export default Blog
